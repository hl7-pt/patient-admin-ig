# Downloads - HL7 PT FHIR Implementation Guide: Example IG Release 1 | STU1 v1.0.0

* [**Table of Contents**](toc.md)
* **Downloads**

## Downloads

 Download the entire implementation guide [here](full-ig.zip) 

* Artifact Definitions: Examples
  * [XML](definitions.xml.zip): [XML](examples.xml.zip)
  * [JSON](definitions.json.zip): [JSON](examples.json.zip)
  * [Turtle](definitions.ttl.zip): [Turtle](examples.ttl.zip)

